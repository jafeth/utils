import os
from io import BytesIO
from lxml import etree

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.solr import api as solr


class CoreCopier(object):
    _schema_find_filters = etree.XPath('//fieldType//filter[@class=$class_name]')
    _filter_class_file_attribute_map = [
        ('solr.SynonymFilterFactory', 'synonyms'),
        ('solr.SynonymGraphFilterFactory', 'synonyms'),
        ('solr.TypeTokenFilterFactory', 'types'),
        ('solr.WordDelimiterFilterFactory', 'protected'),
        ('solr.WordDelimiterFilterFactory', 'types'),
        ('solr.WordDelimiterGraphFilterFactory', 'protected'),
        ('solr.WordDelimiterGraphFilterFactory', 'types'),
        ('solr.CommonGramsFilterFactory', 'words'),
        ('solr.KeepWordFilterFactory', 'words'),
        ('solr.StopFilterFactory', 'words'),
        ('solr.SuggestStopFilterFactory', 'words')
    ]

    def __init__(self, ansible_module):
        self.ansible = ansible_module
        self.changed = False
        self._core = solr.Core(self.local_uri, self.core_name)
        self._conf_dir = None
        self.xml_parser = etree.XMLParser(remove_blank_text=True, remove_comments=True)
        self.config_modifiers = [self.modify_config_managed_schema, self.modify_config_remove_replication_handlers]
        self.additional_files = set()

    @property
    def check_mode(self):
        return self.ansible.check_mode

    @property
    def core_name(self):
        return self.ansible.params['core']

    @property
    def local_uri(self):
        return self.ansible.params['local_api']

    @property
    def remote_uri(self):
        return self.ansible.params['remote_api']

    @property
    def managed_schema(self):
        return self.ansible.params['force_managed_schema']

    @property
    def core(self):
        if self._core is None:
            self._core = solr.Core(self.local_uri, self.core_name)

        return self._core

    @property
    def owner(self):
        return self.ansible.params['owner']

    @property
    def group(self):
        return self.ansible.params['group']

    @property
    def mode(self):
        return self.ansible.params['mode']

    @property
    def conf_dir(self):
        if self._conf_dir is None:
            self._conf_dir = os.path.join(self.core.system.home, self.core.name, 'conf')
            self._create_dir(path=os.path.dirname(self._conf_dir)) \
                ._create_dir(path=self._conf_dir)

        return self._conf_dir

    @property
    def core_result(self):
        core = self.core
        return {
            'name': core.name,
            'schema': core.schema,
            'config': core.config,
            'instance_dir': core.instance_dir,
            'conf_dir': self.conf_dir,
            'additional_files': list(self.additional_files)
        }

    def _create_dir(self, path):
        if not os.path.exists(path):
            os.mkdir(path)
            self.changed = True

        self._set_owner_and_group(path=path)\
            ._set_mode(path=path, mode=self.mode)

        return self

    def _set_owner_and_group(self, path):
        if not os.path.exists(path):
            return self
        am = self.ansible
        self.changed = am.set_owner_if_different(path=path, owner=self.owner, changed=self.changed)
        self.changed = am.set_group_if_different(path=path, group=self.group, changed=self.changed)
        return self

    def _set_mode(self, path, mode):
        if not os.path.exists(path):
            return self
        am = self.ansible
        self.changed = am.set_mode_if_different(path=path, mode=mode, changed=self.changed)
        return self

    def create(self):
        if self.check_mode:
            return self

        self.core.create()
        self._core = None
        return self

    def modify_config_managed_schema(self, config_tree):
        if not self.managed_schema:
            return self

        schema_factory = config_tree.xpath('/config/schemaFactory')[0]
        if schema_factory.get('class') == 'ManagedIndexSchemaFactory':
            return self

        schema_factory.set('class', 'ManagedIndexSchemaFactory')
        etree.SubElement(schema_factory, 'bool', attrib={'name': 'mutable'}).text = 'true'
        etree.SubElement(schema_factory, 'str', attrib={'name': 'managedSchemaResourceName'}).text = 'managed-schema'
        self.changed = True
        return self

    def modify_config_remove_replication_handlers(self, config_tree):
        replication_handlers = config_tree.xpath("/config/requestHandler[@class='solr.ReplicationHandler']")
        for handler in replication_handlers:
            handler.getparent().remove(handler)
            self.changed = True

        return self

    def copy_config(self):
        file_api = solr.FileAdmin(base_uri=self.remote_uri, core=self.core.name)
        path = os.path.join(self.conf_dir, file_api.core.config)
        self.core.config = os.path.basename(path)
        if os.path.exists(path):
            return self

        xml = etree.parse(BytesIO(file_api.config), self.xml_parser)
        for modifier in self.config_modifiers:
            modifier(xml)

        return self._write_xml(path=path, xml_tree=xml)

    def schema_lookup_additional_files(self, schema_tree):
        for (class_name, attribute_name) in self._filter_class_file_attribute_map:
            filters = self._schema_find_filters(schema_tree, class_name=class_name)
            for f in filters:
                file_name = f.get(attribute_name)
                if file_name:
                    self.additional_files.add(file_name)

        return self

    def copy_schema(self):
        schema_api = solr.SchemaAdmin(base_uri=self.remote_uri, core=self.core.name)
        path = os.path.join(self.conf_dir, 'schema.xml')
        self.core.schema = os.path.basename(path)
        if os.path.exists(path):
            return self

        xml = etree.parse(BytesIO(schema_api.schema_xml), self.xml_parser)
        self.schema_lookup_additional_files(xml)
        return self._write_xml(path=path, xml_tree=xml)

    def copy_additional_files(self):
        file_api = solr.FileAdmin(base_uri=self.remote_uri, core=self.core.name)
        for file_name in self.additional_files:
            path = os.path.join(self.conf_dir, file_name)
            if os.path.exists(path):
                continue

            file_content = file_api.get_file_content(file_name)
            self._write_file(path=path, content=file_content)

        return self

    def _write_file(self, path, content):
        if self.check_mode:
            return self

        local_file = open(path, mode='w')
        local_file.write(content)
        local_file.close()
        self.changed = True
        return self._set_owner_and_group(path=path)

    def _write_xml(self, path, xml_tree):
        if self.check_mode:
            return self
        encoding = xml_tree.docinfo.encoding
        xml_tree.write(path, xml_declaration=True, encoding=encoding, pretty_print=True)
        return self._set_owner_and_group(path=path)


def main():
    ansible_module = AnsibleModule(
        argument_spec=dict(
            core=dict(required=True, type='str'),
            remote_api=dict(required=True, type='str'),
            local_api=dict(required=True, type='str'),
            force_managed_schema=dict(type='bool', default=True),
            owner=dict(required=False, default='solr'),
            group=dict(required=False, default='solr'),
            mode=dict(required=False, default='0755')
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    copier = CoreCopier(ansible_module=ansible_module)

    if copier.core.exists:
        ansible_module.exit_json(changed=copier.changed, core=copier.core_result)

    copier.copy_config() \
        .copy_schema() \
        .copy_additional_files() \
        .create()

    ansible_module.exit_json(changed=copier.changed, core=copier.core_result)


if __name__ == '__main__':
    main()
