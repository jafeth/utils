#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import re
import urllib2
from ansible.module_utils.basic import AnsibleModule
from lxml import etree


class SchemaParser:
    _managed_class = "solr.ManagedSynonymFilterFactory"
    _synonym_class = "solr.SynonymFilterFactory"
    _xpath_query = "//fieldType//filter[@class='%s']" % _synonym_class
    _schema_endpoint = "%s/%s/schema?wt=schema.xml"
    _file_endpoint = "%s/%s/admin/file?file=%s"
    _re_synonym_type = re.compile('^([^_.]+).*(?:\.\w+)?$')

    def __init__(self, core, path, api):
        self.api = api
        self.core = core
        self.synonyms = {}
        self.changed = False
        self.path = path
        self.tree = self._get_tree()

    def _get_tree(self):
        return etree.parse(self._schema_endpoint % (self.api, self.core))

    def _synonyms_from_file(self, synonym_type, file_name):
        f = urllib2.urlopen(self._file_endpoint % (self.api, self.core, file_name))
        self.synonyms[synonym_type] = []
        for line in f.readlines():
            self.synonyms[synonym_type].append(line.strip().split(', '))

    def _modify_synonym_filters(self, element):
        if element.get('class') == self._managed_class:
            return False

        element.set('class', self._managed_class)

        file_name = element.attrib.pop('synonyms')
        match = self._re_synonym_type.search(file_name)
        if match:
            synonym_type = match.group(1)
            element.set('managed', synonym_type)
            self._synonyms_from_file(synonym_type, file_name)

        return True

    def process_synonym_filters(self):
        self.changed = False
        synonym_filters = self.tree.xpath(self._xpath_query)
        for filter_element in synonym_filters:
            self.changed = self._modify_synonym_filters(filter_element) or self.changed

    def write(self, overwrite):
        if not overwrite and os.path.lexists(self.path):
            return

        self.tree.write(self.path, xml_declaration=True, encoding='UTF-8', pretty_print=True)
        self.changed = True


def main():
    module = AnsibleModule(
        argument_spec=dict(
            core=dict(required=True),
            path=dict(type='path', required=True),
            remote=dict(required=True),
            force=dict(type='bool', default=True),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
    )

    params = module.params

    schema = SchemaParser(params['core'], params['path'], params['api'])
    if params['managed_synonyms']:
        schema.process_synonym_filters()

    if not module.check_mode:
        schema.write(params['force'])

    module.exit_json(changed=schema.changed, core=schema.core, synonyms=schema.synonyms)


if __name__ == '__main__':
    main()
