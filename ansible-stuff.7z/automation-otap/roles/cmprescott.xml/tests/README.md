ansible-xml Tests
=================

Work in progress.
See also: https://servercheck.in/blog/testing-ansible-roles-travis-ci-github